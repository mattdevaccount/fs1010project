import express from 'express';
import dataHandler from './dataHandler.js';
import { v4 as uuidv4 } from 'uuid';
import jwtVerify from '../verification/jwtVerify.js';

const router = express.Router();
const idPath = dataHandler.formPath;

// post to create entry when submitting contact form
router.post('/contact_form/entries', (req, res) => {

    const errors = []

    if (req.body.name == null) {
        errors.push("name")
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(req.body.email) || req.body.email == null) {
        errors.push("email")
    }

    if (req.body.phoneNumber == null) {
        errors.push("phoneNumber")
    }

    if (req.body.content == null) {
        errors.push("content")
    }

    if (errors.length > 0) {
        return res.status(400).send({message: "validation error", "invalid": errors})
    }

    req.body.id = uuidv4();

    dataHandler.addForm(req.body)
    return res.status(201).send(req.body)
})

//get contact entries with correct token verification
router.get('/contact_form/entries', async (req, res) => {
    res.send(await dataHandler.getAll(dataHandler.formPath))
})

//searching by id functionality

router.get('/contact_form/entries/:id', async (req, res) => {
    const condensedPath = await dataHandler.getAll(idPath);
    console.log(idPath)
    const searchResult = condensedPath.filter(condensedPath => condensedPath.id == req.params.id)
    if (searchResult.length > 0) {
       return res.send(searchResult)
    }
    
    return res.status(404).send({message: `entry ${req.params.id} not found`})
})


export default router;