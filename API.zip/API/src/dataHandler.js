import { promises as fs, write } from 'fs'

const formPath = './data/formData.json';
const userPath = './data/users.json';

const writeFile = async (data, path) => await fs.writeFile(path, JSON.stringify(data))

const getAll = async (path) => JSON.parse(await fs.readFile(path))

const addForm = async data => {
    let content = await getAll(formPath)
    content.push(data)
    await writeFile(content, formPath);
}

const addUser = async data => {
        let content = await getAll(userPath)
        content.push(data)
        await writeFile(content, userPath);
}

export default {
    getAll,
    addForm,
    addUser,
    formPath,
    userPath
}